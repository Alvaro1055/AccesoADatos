package com.teoria;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

public class Serializar {

    public static void main(String[] args) {
        
        System.out.println("Serializar XML");
        XmlMapper mapear = new XmlMapper();
        Cliente cliente = new Cliente();
        cliente.setNombre("Juan");
        cliente.setCiudad("Madrid");
        cliente.setFacturacion(1500);
        System.out.println(cliente.getNombre());
        
        try {
            String guardarCliente = mapear.writeValueAsString(cliente);
            System.out.println(guardarCliente);
            File xmlOutput = new File("serialized.xml");
            FileWriter fileWriter = new FileWriter(xmlOutput);
            fileWriter.write(guardarCliente);
            fileWriter.close();

        } catch (JsonProcessingException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        
        } catch (IOException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    }

    }

}
