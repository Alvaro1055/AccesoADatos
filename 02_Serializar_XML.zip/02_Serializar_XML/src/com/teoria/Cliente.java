package com.teoria;

public class Cliente {
	private String nombre;
	private String ciudad;
	private int facturacion;
	
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getCiudad() {
		return ciudad;
	}
	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}
	public int getFacturacion() {
		return facturacion;
	}
	public void setFacturacion(int facturacion) {
		this.facturacion = facturacion;
	}
	
	
	
	
	
}
